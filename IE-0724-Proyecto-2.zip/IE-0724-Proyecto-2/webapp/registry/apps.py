from django.apps import AppConfig


class RegistryConfig(AppConfig):
    name = 'registry'
